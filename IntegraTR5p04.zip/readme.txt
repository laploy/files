Integra TR Field Programming Software                                  Copyright 2007 Dataradio COR Ltd.

May 2007  Version 5.04.00

This CD contains an autorun feature which should execute when placed in the CD-ROM drive. 
If the autorun does not execute, run setup.exe. This will begin installation of the 
Integra TR Field Programming software. 

********************************************************************************************************

All technical information on this CD is copyright of Dataradio COR Ltd. Any information contained in these 
files is subject to change without notice.