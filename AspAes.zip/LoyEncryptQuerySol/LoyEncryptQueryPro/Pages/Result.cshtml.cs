// Laploy July 2025
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Text;
using System.Security.Cryptography;

namespace LoyEncryptQueryPro.Pages
{
    public class ResultModel : PageModel
    {
        public string DecryptMessage = string.Empty;

        [BindProperty(SupportsGet = true)]
        public string Message { get; set; } = "";

        public void OnGet()
        {
            DecryptMessage = Decrypt(Message);
        }

        private static string Decrypt(string encryptedText)
        {
            string myKey = "$ASPcAwSNIgcPPEoTSa0ODw#";
            byte[] myBytes = Encoding.UTF8.GetBytes(myKey);
            byte[] myEencryptBytes = Convert.FromBase64String(encryptedText);

            using Aes myAes = Aes.Create();
            myAes.Key = myBytes;
            myAes.Mode = CipherMode.ECB;
            myAes.Padding = PaddingMode.PKCS7;

            byte[]? myDecryptBytes = null;
            using (ICryptoTransform decryptor = myAes.CreateDecryptor())
            {
                myDecryptBytes = decryptor.TransformFinalBlock(
                    myEencryptBytes, 0, myEencryptBytes.Length);
            }
            return Encoding.UTF8.GetString(myDecryptBytes);
        }

    }
}

