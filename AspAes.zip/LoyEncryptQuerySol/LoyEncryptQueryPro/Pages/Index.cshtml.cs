// Laploy July 2025
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Text;
using System.Security.Cryptography;

namespace LoyEncryptQueryPro.Pages;

public class IndexModel : PageModel
{
    [BindProperty(SupportsGet = true)]
    public string Message { get; set; } = "";

    public IActionResult OnPost()
    {
        Message = Encrypt(Message);
        return RedirectToPage("Result", new { message = Message });
    }

    private static string Encrypt(string plainText)
    {
        string myKey = "$ASPcAwSNIgcPPEoTSa0ODw#";
        byte[] myBytes = Encoding.UTF8.GetBytes(myKey);
        byte[] myPlainTextBytes = Encoding.UTF8.GetBytes(plainText);

        using Aes myAes = Aes.Create();
        myAes.Key = myBytes;
        myAes.Mode = CipherMode.ECB;
        myAes.Padding = PaddingMode.PKCS7;

        byte[]? myEncryptBytes = null;
        using (ICryptoTransform encryptor = myAes.CreateEncryptor())
        {
            myEncryptBytes = encryptor.TransformFinalBlock(
                myPlainTextBytes, 0, myPlainTextBytes.Length);
        }
        return Convert.ToBase64String(myEncryptBytes);
    }
}






