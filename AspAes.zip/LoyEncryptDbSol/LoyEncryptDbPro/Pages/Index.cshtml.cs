// Laploy July 2025
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Text;
using System.Security.Cryptography;

namespace LoyEncryptDbPro.Pages;

public class IndexModel : PageModel
{
    [BindProperty(SupportsGet = true)]
    public string Message { get; set; } = "";

    public IActionResult OnPost()
    {
        return RedirectToPage("Result", new { message = Message });
    }
}

