// Laploy July 2025
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Security.Cryptography;
using System.Text;

namespace LoyEncryptDbPro.Pages
{
    public class ResultModel : PageModel
    {
        [BindProperty(SupportsGet = true)]
        public string Message { get; set; } = "";
        public string? myMessage;

        public void OnGet()
        {
            myMessage = Encrypt(Message);
        }

        private static string Encrypt(string plainText)
        {
            string myKey = "$ASPcAwSNIgcPPEoTSa0ODw#";
            byte[] myBytes = Encoding.UTF8.GetBytes(myKey);
            byte[] myPlainTextBytes = Encoding.UTF8.GetBytes(plainText);

            using Aes myAes = Aes.Create();
            myAes.Key = myBytes;
            myAes.Mode = CipherMode.ECB;
            myAes.Padding = PaddingMode.PKCS7;

            byte[]? myEncryptBytes = null;
            using (ICryptoTransform encryptor = myAes.CreateEncryptor())
            {
                myEncryptBytes = encryptor.TransformFinalBlock(
                    myPlainTextBytes, 0, myPlainTextBytes.Length);
            }
            return Convert.ToBase64String(myEncryptBytes);
        }
    }
}
